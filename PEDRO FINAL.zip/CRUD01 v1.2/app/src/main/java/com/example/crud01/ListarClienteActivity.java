package com.example.crud01;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
// necessario para o menu
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.SearchView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
public class ListarClienteActivity extends AppCompatActivity {

    private ListView listview;
    private ClienteDAO dao;
    private List<Cliente> clientes;
    private List<Cliente> clientesFiltrados = new ArrayList<>();
    ArrayAdapter<Cliente> adaptador1;
    ClienteAdapter adaptador;
    ClienteAdapter adaptador2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_clientes);
    }

    public void onResume() {
        super.onResume();

        listview = findViewById(R.id.lista_clientes);
        dao = new ClienteDAO(this);
        clientes = dao.obterTodos();
        adaptador1 = new ArrayAdapter<Cliente>(this, android.R.layout.simple_list_item_1, clientes);
        adaptador = new ClienteAdapter(this, clientes);
        adaptador2 = new ClienteAdapter(this, clientesFiltrados);
        listview.setAdapter(adaptador);
        registerForContextMenu(listview);
    }

    // Menu Inclusao e busca
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_principal, menu);
        MenuItem menuItem = menu.findItem(R.id.app_bar_search); // botao busca do menu
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setQueryHint("Procurar ");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                procuraCliente(newText);
                return false;
            }
        });
        return true;
    }

    // exclusão
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.menu_contexto, menu);
    }

    public void cadastrar(MenuItem item) {
        setContentView(R.layout.activity_tela_login);
        TextView tUsuario = findViewById(R.id.txtUsuario);
        String login = tUsuario.getText().toString();
        Intent it = new Intent(this, MainActivity.class);
        it.putExtra("txtUsuario", login);
        startActivity(it);
    }
    public void procuraCliente(String nome){
        clientesFiltrados.clear();
        for(Cliente c : clientes){
            if(c.getNome().toLowerCase().contains(nome.toLowerCase())) {
                clientesFiltrados.add(c);
                listview.setAdapter(adaptador2);
                registerForContextMenu(listview);
            }
        }
        listview.invalidateViews();
    }
    public void excluir(MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        if (clientesFiltrados.isEmpty() ) {
            final Cliente clienteExcluir = clientes.get(menuInfo.position);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Atenção")
                    .setMessage("Deseja mesmo excluir o cliente?")
                    .setNegativeButton("Não", null)
                    .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int i) {
                            clientesFiltrados.remove(clienteExcluir);
                            clientes.remove(clienteExcluir);
                            dao.excluir(clienteExcluir);
                            listview.invalidateViews();
                            Intent it = new Intent(ListarClienteActivity.this, ListarClienteActivity.class);
                            startActivity(it);
                        }
                    }).create();
            dialog.show();
        }
        else {
            final Cliente clienteExcluir = clientesFiltrados.get(menuInfo.position);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Atenção")
                    .setMessage("Deseja mesmo excluir o cliente?")
                    .setNegativeButton("Não", null)
                    .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int i) {
                            clientesFiltrados.remove(clienteExcluir);
                            clientes.remove(clienteExcluir);
                            dao.excluir(clienteExcluir);
                            listview.invalidateViews();
                            Intent it = new Intent(ListarClienteActivity.this, ListarClienteActivity.class);
                            startActivity(it);
                        }
                    }).create();
            dialog.show();
        }
    }
    public void atualizar(MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        if (clientesFiltrados.isEmpty() ) {
            final Cliente clienteAtualizar = clientes.get(menuInfo.position);
            Intent it = new Intent(ListarClienteActivity.this, MainActivity.class);
            it.putExtra("cliente", clienteAtualizar);
            startActivity(it);
        }
        else{
            final Cliente clienteAtualizar = clientesFiltrados.get(menuInfo.position);
            Intent it = new Intent(ListarClienteActivity.this, MainActivity.class);
            it.putExtra("cliente", clienteAtualizar);
            startActivity(it);
        }

    }
}
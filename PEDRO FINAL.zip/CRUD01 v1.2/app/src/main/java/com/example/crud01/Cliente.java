package com.example.crud01;


import androidx.annotation.NonNull;

import java.io.Serializable;

public class Cliente implements Serializable {

    private Integer id;

    public Cliente() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    private String nome;
    private String matricula;
    private String cidade;
    private String estado;

    @NonNull
    @Override
    public String toString(){
        return nome;
    }

}
package com.example.crud01;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;


public class ClienteAdapter extends BaseAdapter {

    private List<Cliente> cliente;
    private Activity activity;

    public ClienteAdapter( Activity activity, List<Cliente> cliente){
        this.activity = activity;
        this.cliente = cliente;
    }

    @Override
    public int getCount(){
        return cliente.size();
    }

    @Override
    public Object getItem(int i) {
        return cliente.get(i);
    }

    @Override
    public long getItemId(int i) {
        return cliente.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
       View v = activity.getLayoutInflater().inflate(R.layout.item, viewGroup, false);
        TextView nome = v.findViewById(R.id.txt_nome);
        TextView matricula = v.findViewById(R.id.txt_matricula);
        TextView cidade = v.findViewById(R.id.txt_cidade);
        TextView estado = v.findViewById(R.id.txt_estado);
        Cliente c = cliente.get(i);
        nome.setText(c.getNome());
        matricula.setText(c.getMatricula());
        cidade.setText(c.getCidade());
        estado.setText(c.getEstado());
        return v;
    }

}

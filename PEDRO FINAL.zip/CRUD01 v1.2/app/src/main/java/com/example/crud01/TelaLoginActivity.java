package com.example.crud01;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TelaLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);
        Button btLogin = findViewById(R.id.btnLogin);
        btLogin.setOnClickListener(view -> {
            findViewById(R.id.txtUsuario);
            TextView tUsuario = findViewById(R.id.txtUsuario);
            TextView tSenha = findViewById(R.id.txtSenha);
            String login = tUsuario.getText().toString();
            String senha = tSenha.getText().toString();
            if(login.equals("pedro")&&senha.equals("123") || login.equals("edinho")&&senha.equals("123")){
                alert("O login foi realizado com sucesso!!");
                // PUXA 2 TELA
                Intent intent = new Intent(TelaLoginActivity.this, MainActivity.class);
                intent.putExtra("txtUsuario", login);
                startActivity(intent);
            }
            else {
                alert("Login e/ou Senha invalido(s)");
            }
        });
    }
    private void alert(String s) {
            Toast.makeText(this,s, Toast.LENGTH_LONG).show();
        }
    }
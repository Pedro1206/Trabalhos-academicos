package com.example.crud01;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Conexao extends SQLiteOpenHelper {
    private static final String nome = "banco.db";
    private static final int version = 1;
    //private static final SQLiteDatabase.CursorFactory factory = null;
    public Conexao (Context context) {
        super(context, nome, null, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table cliente (id integer primary key autoincrement," +
                "matricula varchar(10), nome varchar(50), cidade varchar(10), estado varchar(10))");
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {


    }

}

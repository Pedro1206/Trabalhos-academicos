package com.example.crud01;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    private EditText nome;
    private EditText matricula;
    private EditText cidade;
    private EditText estado;
    private ClienteDAO dao;
    private Cliente cliente = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent it = getIntent();
        if(it.hasExtra("cliente")){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_atualizar);

        }
        else{
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            String usuario2 = it.getStringExtra("txtUsuario");
            TextView tv = findViewById(R.id.txt_Usuario);
            tv.setText("Bem Vindo " + usuario2 + " ao formulário");
        }
// Vincular os campos do layout com as variaveis do java
        nome = (EditText) findViewById(R.id.txtNome);
        matricula = (EditText) findViewById(R.id.txtMatricula);
        cidade = (EditText) findViewById(R.id.txtCidade);
        estado =(EditText) findViewById(R.id.txtEstado);

// iniciar o atributo dao
        dao = new ClienteDAO(this);

  //      Intent it = getIntent();
        if(it.hasExtra("cliente")){
            cliente = (Cliente) it.getSerializableExtra("cliente");
            nome.setText(cliente.getNome());
            matricula.setText(cliente.getMatricula());
            cidade.setText(cliente.getCidade());
            estado.setText(cliente.getEstado());
        }
    }

    public void salvar(View view){
        if (cliente == null) {
            Cliente c = new Cliente();
            c.setMatricula(matricula.getText().toString());
            c.setNome(nome.getText().toString());
            c.setCidade(cidade.getText().toString());
            c.setEstado(estado.getText().toString());
            // gravar cliente
            long id = dao.inserir(c);
            // exibir uma mensagem
            Toast.makeText(this, "Cliente cadastrado com sucesso com id" + id,
                    Toast.LENGTH_SHORT).show();
            Intent it = new Intent(MainActivity.this, ListarClienteActivity.class);
            startActivity(it);
        } else {
            cliente.setMatricula(matricula.getText().toString());
            cliente.setNome(nome.getText().toString());
            cliente.setCidade(cidade.getText().toString());
            cliente.setEstado(estado.getText().toString());
            dao.atualizar(cliente);
            Toast.makeText(this, "Cliente atualizado com sucesso",
                    Toast.LENGTH_SHORT).show();
            Intent it = new Intent(MainActivity.this, ListarClienteActivity.class);
            startActivity(it);
        }
    }
}
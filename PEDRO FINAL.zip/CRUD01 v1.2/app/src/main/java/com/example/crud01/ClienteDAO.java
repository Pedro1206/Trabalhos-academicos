package com.example.crud01;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;
public class ClienteDAO {
    // Vamos criar
// objeto para conexao com a classe cliente e o Sqlite
// Criar um metodo construtor
//iniciar o banco para a escrita
    public Conexao conexao;
    public SQLiteDatabase banco;
    public ClienteDAO(Context context){
        conexao = new Conexao(context);
        banco = conexao.getWritableDatabase();
    }
    // Metodo para inserir um cliente
    public long inserir(Cliente cliente){
        ContentValues values = new ContentValues();
        values.put("matricula", cliente.getMatricula());
        values.put("nome", cliente.getNome());
        values.put("cidade", cliente.getCidade());
        values.put("estado", cliente.getEstado());
        return banco.insert("cliente", null, values);
    }
    public List<Cliente> obterTodos(){
        List<Cliente> clientes = new ArrayList<>();
        Cursor cursor = banco.query("cliente", new String[] {"id", "matricula", "nome", "Cidade", "Estado"},
                null, null, null, null, null);
        while(cursor.moveToNext()) {
            Cliente c = new Cliente();
            c.setId(cursor.getInt(0));
            c.setMatricula(cursor.getString(1));
            c.setNome(cursor.getString(2));
            c.setCidade(cursor.getString(3));
            c.setEstado(cursor.getString(4));
            clientes.add(c);
        }
        return clientes;
    }
    public void excluir(Cliente c) {
        banco.delete("cliente","id = ?", new String[] {c.getId().toString()});
    }
    public void atualizar(Cliente c){
        ContentValues values = new ContentValues();
        values.put("matricula", c.getMatricula());
        values.put("nome", c.getNome());
        values.put("cidade", c.getCidade());
        values.put("estado", c.getEstado());
        banco.update("cliente", values,
                "id = ?", new String[] {c.getId().toString()});
    }
}